__all__ = ['print_messages', 'check_pedal', 'midi2piece', 'Pitch', 'Note',
           'Piece', 'plot_time_frequency', 'Synthesizer', 'synthesize', 
           'get_amplitudes', 'get_decay_function', 'midi_to_hertz', 
           'hertz_to_midi', 'frequency_to_notes', 'ticks2seconds', 
           'velocity_to_amplitude']
