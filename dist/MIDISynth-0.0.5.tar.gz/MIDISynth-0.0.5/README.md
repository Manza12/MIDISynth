# MIDISynth

This package serves for synthesizing audio from MIDI files.